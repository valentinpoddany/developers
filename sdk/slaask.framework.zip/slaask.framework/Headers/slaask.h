//
//  slaask.h
//  slaask
//
//  Created by Aleksey Gorbachevskiy on 10/12/16.
//  Copyright © 2016 Omertex. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for slaask.
FOUNDATION_EXPORT double slaaskVersionNumber;

//! Project version string for slaask.
FOUNDATION_EXPORT const unsigned char slaaskVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <slaask/PublicHeader.h>


